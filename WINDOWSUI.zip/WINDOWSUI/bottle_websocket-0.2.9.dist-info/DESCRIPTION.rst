Easy websockets for bottle.


