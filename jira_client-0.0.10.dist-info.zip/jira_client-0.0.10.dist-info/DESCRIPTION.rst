This project provides a client library for working with Jira boards, epics, sprints and issues.


